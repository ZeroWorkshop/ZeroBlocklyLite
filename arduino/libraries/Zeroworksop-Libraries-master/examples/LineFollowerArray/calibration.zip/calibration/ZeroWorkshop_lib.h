
#ifndef ZeroWorkshop_lib_h
#define ZeroWorkshop_lib_h
#include "ZeroWorkshop_lib.h"
#include "ZeroWorkshop_Macro_Definitions.h"
#include <math.h> 
#include <stdio.h>
#include <Arduino.h>
#include <Servo.h>
#include <Adafruit_NeoPixel.h>


#define FORWARD    		0
#define BACKWARD    	1
#define STOP    			2


void StartProgram(int *ProgramSelector); 
bool PS2_RF_Button(uint16_t ButtonPressed);

bool PS2_RF_ReadButton(int *Button_Buffer);

void playNote(int Note,int Meter,int Length);

void playNoteShort(int Note,int Meter,int Length);

void playSong(int songSelected);


#endif