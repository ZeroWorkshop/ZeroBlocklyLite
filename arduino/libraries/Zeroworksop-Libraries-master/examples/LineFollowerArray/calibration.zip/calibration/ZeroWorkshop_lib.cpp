#include "ZeroWorkshop_lib.h"
#include "ZeroWorkshop_Macro_Definitions.h"

#include <Arduino.h>
#include <Servo.h>
#include <EEPROM.h>

#include <string.h>


static void (*reset_this_CPU)(void) = 0x0000; // ***婵瀀垼倀涚瀀宕倀礊退涙怀瀚倀柣倀堢怀U退佸怀鍨倀慨退夊怀閻怀厧瀀伴怀銉墯退氾怀

struct ProgNumInEPROM {
  int lastProgSelected;
};
int followFlag = 1;
int buffer_index = 0;

bool GrabActionCompleted = false;
bool PutActionCompleted = false;

long startTimeLeft = 0;
long startTimeRight = 0;
bool leftLEDLastState = LOW;
bool rightLEDLastState = LOW;

int isFollowFlag = 0;
long scoreTime = 0;

long mouthTime = 0;

int fanHeadMove_direction = 1;

int radar_dir = 1;

long startTimeKnock = 0;
bool hammerState = LOW;

long startTimeAttacked = 0;

int lastAttackedSensorState = HIGH;
int AttackedSensorState = HIGH;

int flash_times = 0;
bool LEDFlashState = false;

#define NumberOfProgram 1   //define the number of programs that stored in the CPU

int NOTE[] = {
  c5, c4, d4, e4, f4, g4, a4, b4, c5, d5, e5, f5
};


int TuningStatus = 0;
float LoaderPosition[] = {0, 53, 72, 97, 121, 146, 168};

struct ServoAngles {
  float positionValue[7];
};



#define buttonL1 (0x4 & ControlButton_Read[3])
#define buttonL2 (0x1 & ControlButton_Read[3])
#define buttonR1 (0x8 & ControlButton_Read[3])
#define buttonR2 (0x2 & ControlButton_Read[3])
#define Select   (0x1 & ControlButton_Read[2])


// note durations: 4 = quarter note, 8 = eighth note, etc.:
int noteDurations[] = {8, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4};

int ButtonState;                    // variable to store button state

int lastButtonState;                // variable to store last button state

//int ProgramSelector;

bool KeepOnReadButton;

bool ReadButtonState;

long ButtonInterval = 2000;

long startTime ;                    // start time for stop watch

long elapsedTime ;                  // elapsed time for stop watch
void StartProgram(int *ProgramSelector)
{
  ProgNumInEPROM ProgToBeSelected;
  ProgNumInEPROM lastRunProg;

  int eepromAddr = eeAddr_LEVEL1_DEFAULT_PROG;

  EEPROM.get(eepromAddr, lastRunProg);
  if (lastRunProg.lastProgSelected == 0) {
    ProgToBeSelected.lastProgSelected = 1;
    EEPROM.put(eepromAddr, ProgToBeSelected);
  }


  Serial.begin(115200);

  pinMode(BuzzerPin, OUTPUT);
  pinMode(START_BUTTON, INPUT);
  digitalWrite(START_BUTTON, HIGH);


  int bullet_left = bulletNumber;
  int noteDuration = 1000 / noteDurations[0];
  int pauseBetweenNotes = noteDuration * 1.30;

  playNote(c4, eighthNote, meters_x1);
  playNote(e4, eighthNote, meters_x1);
  playNote(g4, eighthNote, meters_x1);
  playNote(c5, quaterNote, meters_x1);

  (*ProgramSelector) = -1;
  KeepOnReadButton = true;

  while (KeepOnReadButton) {


    ReadButtonState = true;
    while (ReadButtonState) {
      //TuningLoader(bulletLoader_servo, bulletTrigger_servo, &bullet_left) ;
      lastButtonState = ButtonState;
      delay(10);                                           //make a 10ms interval between successive reading. This is to make sure the button state is stable enough
      ButtonState = digitalRead(START_BUTTON);

      if ((*ProgramSelector) == -1 && ButtonState == HIGH) {    //if no program is selected, keep on read the button state
        //      if (ButtonState == HIGH) {    //if no program is selected, keep on read the button state
        ReadButtonState = true;
      }
      else if ((*ProgramSelector) >= 0 && ButtonState == HIGH && lastButtonState == HIGH) {     //if one program is selected and the next program is not selected in ButtonInterval(initially 2 seconds) time, the program selected will  run
        elapsedTime =   millis() - startTime;   // store elapsed time

        if (elapsedTime > ButtonInterval) {
          ReadButtonState = false;
          KeepOnReadButton = false;
        }
        else {
          ReadButtonState = true;
          KeepOnReadButton = true;
        }
      }
      else if (ButtonState == LOW && lastButtonState == LOW) {      //if the button is kept on being pressed, keep on reading the the state until the button is released.
        ReadButtonState = true;

      }
      else if (ButtonState == HIGH && lastButtonState == LOW) {      //if a low to high transition is found, it means the user just release the button. Reset the timer and wait button to be pressed for ButtonInterval(intially 2 seconds).
        startTime = millis();                                   // reset the start time
        ReadButtonState = true;

      }
      else if (ButtonState == LOW && lastButtonState == HIGH) {        //if a high to low transition is found, it means the user can select program. Stop reading the button, the corresponding tone will be played.
        ReadButtonState = false;
        (*ProgramSelector)++;
        break;
      }
    }

    if ((*ProgramSelector) > NumberOfProgram) {          //If times of StartButton pressed more than the number of program, program selector goes to the first program
      (*ProgramSelector) = 1;
    }


    if (ButtonState == LOW && lastButtonState == HIGH) {

      startTime = millis();                                   // store the start time

      // to calculate the note duration, take one second
      // divided by the note type.
      //e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.
      noteDuration = 1000 / noteDurations[(*ProgramSelector)];
      tone(SpeakerPIN, NOTE[(*ProgramSelector)], noteDuration);

      // the note's duration + 30% seems to work well:
      pauseBetweenNotes = noteDuration * 1.30;
      delay(pauseBetweenNotes);

      // stop the tone playing:
      noTone(SpeakerPIN);

      //      int eepromAddr = eeAddr_LEVEL1_DEFAULT_PROG;
      //      EEPROM.get(eepromAddr, lastRunProg);
      //      if (lastRunProg.lastProgSelected == 0) {
      //        ProgToBeSelected.lastProgSelected = 1;
      //        EEPROM.put(eepromAddr, ProgToBeSelected);
      //      }

      //      ProgToBeSelected.lastProgSelected = (*ProgramSelector);
      //      Serial.print("###########Program To be saved in EEPROM = ");
      //      Serial.println((*ProgramSelector));
      //      if (ProgToBeSelected.lastProgSelected != 0) {
      //
      //        Serial.print("Program To be saved in EEPROM = ");
      //        Serial.println(ProgToBeSelected.lastProgSelected);
      //
      //        EEPROM.put(eepromAddr, ProgToBeSelected);
      //      }
    }
  }
  ProgToBeSelected.lastProgSelected = (*ProgramSelector);

  if (ProgToBeSelected.lastProgSelected != 0) {

    Serial.print("Program To be saved in EEPROM = ");
    Serial.println(ProgToBeSelected.lastProgSelected);

    EEPROM.put(eepromAddr, ProgToBeSelected);
  }
  else {
    EEPROM.get(eepromAddr, lastRunProg);

    (*ProgramSelector) = lastRunProg.lastProgSelected;
  }

  playNoteShort(e7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(f7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
  delay(100);

  playNoteShort(e7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(f7, sixteenthNote * 0.25, meters_x1);
  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
//  delay(100);
//
//  playNoteShort(e7, sixteenthNote * 0.25, meters_x1);
//  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
//  playNoteShort(f7, sixteenthNote * 0.25, meters_x1);
//  playNoteShort(g7, sixteenthNote * 0.25, meters_x1);
}



bool PS2_RF_Button(uint16_t ButtonPressed)
{
  byte PS2_RF_buffer[6];
  bool PAD_LeftKey;

  uint8_t UpperByte = ButtonPressed >> 8;
  uint8_t LowerByte = ButtonPressed & 0xff;

  if (Serial.available() > 0) {
    Serial.readBytes(PS2_RF_buffer, 6);  //the decoded data is a 6 byte data


    Serial.print("Expected 16bit value is: 0x");
    Serial.println(ButtonPressed, HEX);

    Serial.print("Left Pad Recieved is:");
    Serial.println(PS2_RF_buffer[2], HEX);
    Serial.print("Right Pad Recieved is:");
    Serial.println(PS2_RF_buffer[3], HEX);

    Serial.print("Left Pad Expected is:");
    Serial.println(UpperByte, HEX);
    Serial.print("Right Pad Expected is:");
    Serial.println(LowerByte, HEX);
    if (PS2_RF_buffer[0] != 0xAA || PS2_RF_buffer[1] != 0x55) {
      return false;
    }




    if ((PS2_RF_buffer[2] & UpperByte) != 0) {
      Serial.println("Pad left button matched!");
      return true;
    }
    else {
      Serial.println("No Pad left button matched!");
      return false;
    }


    if ((PS2_RF_buffer[3] & LowerByte)) {
      Serial.println("Pad right button matched!");
      return true;
    }
    else {
      Serial.println("No Pad right button matched!");
      return false;
    }



  }
  else return false;
}

bool PS2_RF_ReadButton(int *Button_Buffer)
{
  byte PS2_RF_buffer[6];
  bool PAD_LeftKey;
  int temp;
  bool Re_read_buffer = false;
  int startPosition = 0;


  int bytes = Serial.available();

  /*
    Button_Buffer[2] = 0;
    Button_Buffer[3] = 0;
    Button_Buffer[4] = 0;
    Button_Buffer[5] = 0;
  */
  if (bytes > 0 ) {

    for (int j = 0; j < bytes; j++) {
      temp = Serial.read();
      Serial.print("Byte ");
      Serial.print(j);
      Serial.print(":   ");
      Serial.println(temp, HEX);
      if (temp == 0xAA) buffer_index = 0;

      Button_Buffer[buffer_index] = temp;
      //#if DEBUG
      Serial.print("Byte[");
      Serial.print(buffer_index);
      Serial.print("]: 0x");
      Serial.println(Button_Buffer[buffer_index], HEX);
      //#endif
      buffer_index++;


    }
  }
}

int Rx_Buffer[6];
int temp[6];

/*
 For some unknown reason, the controller data into the serial port sometimes give the wrong sequence. 
 The right sequence is AA 55 RR SS TT UU. A right data is a 6-byte with AA 55 as the first two bytes. 
 However sometimes the byte sequence is less than 6 byte which is a wrong number. It maybe caused by some missing capture. 
 This function is to pick up the right 6-byte sequence as the correct controller data.
 SerialEvent occurs whenever a new data comes in the hardware serial RX. 
 Normally several consective 6-byte data are recieved. But sometimes there are some missing bytes. 
 In this case, we collect the latest valid 6-byte data as the valid controller data.
 */
void serialEvent() {
  if (Serial.available() < 6) return;  //If the total bytes in buffer is less than 6, the data is invalid. Stop the routine without get the data.
  #if	1
  Serial.print("Bytes in buffer is : ");
  Serial.println(Serial.available());
  #endif
  if (Serial.available() % 6) Serial.println("ERROR!!Bytes in UART buffer is not an valid PS2 control data. Data will be discarsed");



  int TotalBytesInBuffer = Serial.available();     
  int latestStartByte = 0;
  int lastStartByte = 0;
  int index;
  int inChar;
  bool valid_controller_data = false;

  for (int j = 0; j < TotalBytesInBuffer; j++) {   //Read out the controller data byte by byte.
    // get the new byte:

    inChar = Serial.read();
#if DEBUG
    Serial.print(j);
    Serial.print(" : ");
    Serial.println(inChar, HEX);
#endif

    if (inChar == 0xAA) {  //Find the head of a controller data. If AA is found, store it as the first byte of a temp controller data.
      index = 0;
    }
    temp[index++] = inChar;
    

    if (index == 6) valid_controller_data = true;  //If there is no another 0xAA before the first 6 byte end, it means the first 6-byte data is valid.
    else valid_controller_data = false;            //Otherwise the data captured is less than 6 bytes which is invalid data.

    if (valid_controller_data) {                   //Give the lastes valid data as the controller data.
      for (int i = 0; i < index; i++) {
        Rx_Buffer[i] = temp[i];
#if 1        
        Serial.print("Latest Controller value is : ");
        Serial.println(Rx_Buffer[i], HEX);
#endif         
      }
    }
   
  }
#if DEBUG
  Serial.print("***********                         0x");
  Serial.println(Rx_Buffer[2], HEX);
#endif
}


void playNote(int Note, int Meter, int Length) {
  tone(BuzzerPin, Note, Meter * Length);
  //  delay(Meter * 1.3 * Length);
  long duration_time = millis();
  for (int i = 0; i < Meter * 1.3 * Length * 200; i++) {
    //    Serial.println(i);
    if (millis() - duration_time > Meter * 1.3 * Length) break;
    //digitalRead(ZW_A1);
  }
  //  noTone(BuzzerPin);
}

void playNoteShort(int Note, int Meter, int Length) {
  tone(BuzzerPin, Note, Meter * Length);
  //  delay(Meter * 1.3 * Length);
  long duration_time = millis();
  for (int i = 0; i < Meter * 1.3 * Length * 200; i++) {
    //    Serial.println(i);
    if (millis() - duration_time > Meter * 1.0 * Length) break;
    //digitalRead(ZW_A1);
  }
  //  noTone(BuzzerPin);
}

void playSong(int songSelected) {
  switch (songSelected) {
  case 1:
    playNote(e4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);
    playNote(f4, eighthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(g4, eighthNote, meters_x1);
    playNote(f4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);
    playNote(d4, eighthNote, meters_x1);

    playNote(c4, eighthNote, meters_x1);
    playNote(c4, eighthNote, meters_x1);
    playNote(d4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(d4, sixteenthNote, meters_x1);
    playNote(d4, eighthNote, meters_x2);



    playNote(e4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);
    playNote(f4, eighthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(g4, eighthNote, meters_x1);
    playNote(f4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);
    playNote(d4, eighthNote, meters_x1);

    playNote(c4, eighthNote, meters_x1);
    playNote(c4, eighthNote, meters_x1);
    playNote(d4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);

    playNote(d4, sixteenthNote, meters_x3);
    playNote(c4, sixteenthNote, meters_x1);
    playNote(c4, eighthNote, meters_x2);


    for (int i = 0; i < 2; i++) {
      playNote(d4, eighthNote, meters_x1);
      playNote(d4, eighthNote, meters_x1);
      playNote(e4, eighthNote, meters_x1);
      playNote(c4, eighthNote, meters_x1);

      playNote(d4, eighthNote, meters_x1);
      playNote(e4, sixteenthNote, meters_x1);
      playNote(f4, sixteenthNote, meters_x1);
      playNote(e4, eighthNote, meters_x1);
      playNote(c4, eighthNote, meters_x1);

      playNote(d4, eighthNote, meters_x1);
      playNote(e4, sixteenthNote, meters_x1);
      playNote(f4, sixteenthNote, meters_x1);
      playNote(e4, eighthNote, meters_x1);
      playNote(d4, eighthNote, meters_x1);

      playNote(c4, eighthNote, meters_x1);
      playNote(d4, eighthNote, meters_x1);
      playNote(g3, eighthNote, meters_x1);
      playNote(e4, eighthNote, meters_x2);

      //playNote(e4,eighthNote,meters_x1);
      playNote(e4, eighthNote, meters_x1);
      playNote(f4, eighthNote, meters_x1);
      playNote(g4, eighthNote, meters_x1);

      playNote(g4, eighthNote, meters_x1);
      playNote(f4, eighthNote, meters_x1);
      playNote(e4, eighthNote, meters_x1);
      playNote(d4, eighthNote, meters_x1);

      playNote(c4, eighthNote, meters_x1);
      playNote(c4, eighthNote, meters_x1);
      playNote(d4, eighthNote, meters_x1);
      playNote(e4, eighthNote, meters_x1);

      playNote(d4, sixteenthNote, meters_x3);
      playNote(c4, sixteenthNote, meters_x1);
      playNote(c4, eighthNote, meters_x2);
    }
    break;

  case 2:
    playNote(c4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(a4, quaterNote, meters_x1);
    playNote(g4, quaterNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(c4, sixteenthNote, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);

    playNote(e4, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(g3, quaterNote / 3, meters_x1);
    playNote(g3, quaterNote / 3, meters_x1);
    playNote(g3, quaterNote / 3, meters_x1);
    playNote(g3, quaterNote / 3, meters_x1);
    playNote(g3, quaterNote / 3, meters_x1);
    playNote(g3, quaterNote / 3, meters_x1);

    playNote(c4, quaterNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);
    playNote(g3, eighthNote, meters_x1);

    playNote(c4, eighthNote, meters_x3);
    playNote(c4, eighthNote, meters_x1);

    playNote(c4, sixteenthNote, meters_x3);
    playNote(c4, sixteenthNote, meters_x1);
    playNote(g3, eighthNote, meters_x1);
    playNote(a3, sixteenthNote, meters_x1);
    playNote(b3, sixteenthNote, meters_x1);

    playNote(c4, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);

    playNote(e4, eighthNote, meters_x1);
    playNote(c4, eighthNote, meters_x1);
    playNote(d4, sixteenthNote, meters_x1);
    playNote(e4, sixteenthNote, meters_x1);

    playNote(g4, quaterNote, meters_x1);
    playNote(g4, quaterNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(c4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);

    playNote(g4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(d4, quaterNote, meters_x1);

    playNote(d4, quaterNote, meters_x2);

    playNote(a4, quaterNote, meters_x1);
    playNote(g4, quaterNote, meters_x1);

    playNote(d4, quaterNote, meters_x1);
    playNote(e4, quaterNote, meters_x1);

    playNote(g4, eighthNote, meters_x1);
    playNote(e4, eighthNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(e4, eighthNote, meters_x1);
    playNote(d4, sixteenthNote, meters_x1);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(e4, quaterNote, meters_x1);
    delay(quaterNote * 1.3 * meters_x1);

    playNote(g3, sixteenthNote, meters_x3);
    playNote(a3, sixteenthNote, meters_x1);
    playNote(c4, eighthNote, meters_x1);
    playNote(c4, eighthNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(d4, eighthNote, meters_x1);
    playNote(d4, sixteenthNote, meters_x1);
    playNote(d4, sixteenthNote, meters_x1);
    playNote(a3, quaterNote, meters_x1);

    playNote(d4, eighthNote, meters_x3);
    playNote(g3, eighthNote, meters_x1);

    playNote(c4, eighthNote, meters_x3);
    playNote(c4, eighthNote, meters_x1);

    playNote(e4, eighthNote, meters_x3);
    playNote(e4, eighthNote, meters_x1);

    playNote(g4, quaterNote, meters_x2);

    playNote(c4, sixteenthNote, meters_x3);
    playNote(e4, sixteenthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);
    playNote(g4, eighthNote, meters_x1);

    playNote(a4, quaterNote, meters_x1);
    playNote(g4, quaterNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(c4, sixteenthNote, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);

    playNote(e4, eighthNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);
    playNote(c4, eighthNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);

    playNote(g3, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(e4, sixteenthNote, meters_x3);
    playNote(c4, sixteenthNote, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);
    playNote(g4, quaterNote / 3, meters_x1);

    playNote(e4, eighthNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);
    playNote(c4, eighthNote, meters_x1);
    delay(eighthNote * 1.3 * meters_x1);

    playNote(g3, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(g3, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(g3, quaterNote, meters_x1);
    playNote(c4, quaterNote, meters_x1);

    playNote(c4, quaterNote, meters_x1);
    delay(quaterNote * 1.3 * meters_x1);
    break;

  case 3:
    break;
  case 4:
    break;

  case 5:
    break;

  default:
    break;
  }

}


#define _ButtonUp        (0x10 & Rx_Buffer[2])
#define _ButtonRight     (0x20 & Rx_Buffer[2])
#define _ButtonDown      (0x40 & Rx_Buffer[2])
#define _ButtonLeft      (0x80 & Rx_Buffer[2])
#define _ButtonTriangle  (0x10 & Rx_Buffer[3])
#define _ButtonCircle    (0x20 & Rx_Buffer[3])
#define _ButtonCross     (0x40 & Rx_Buffer[3])
#define _ButtonSquare    (0x80 & Rx_Buffer[3])
#define _ButtonL1        (0x4 & Rx_Buffer[3])
#define _ButtonL2        (0x1 & Rx_Buffer[3])
#define _ButtonR1        (0x8 & Rx_Buffer[3])
#define _ButtonR2        (0x2 & Rx_Buffer[3])
#define _ButtonSelect    (0x1 & Rx_Buffer[2])
#define _ButtonStart     (0x8 & Rx_Buffer[2])
